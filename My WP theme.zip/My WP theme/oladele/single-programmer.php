<?php
/**
 * The template for displaying all programmer single posts
 
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php while ( have_posts() ) : the_post(); ?>
		
		<h2><?php the_title(); ?></h2>
		<h4>Nickname: <?php the_field('nickname'); ?> </h4>
		<?php the_post_thumbnail(); ?>
		<h4>Age: <?php the_field('age') ?>years old</h4>
		<h4>Nationality: <?php the_field('nationality'); ?></h4>
		<h4>Who is <?php the_title(); ?>? </h4>
		<?php the_content(); ?>
		<h4>Top works done: </h4>
		<?php the_field('top_works') ?>
			

		<?php endwhile; // End of the loop.?>

		</main><!-- #main -->
	</div><!-- #primary -->

<div class="sidebar" id="Programmers-sidebar">
	<?php dynamic_sidebar('programmer-sidebar'); ?>
</div>

<?php
get_footer();
?>
