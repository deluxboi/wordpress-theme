<?php
/**
 * Template Name: Sample Page
 */
?>

<?php get_header(); ?>
<h2><?php the_title('BEGIN ',' END'); ?></h2>
<?php the_post_thumbnail('medium', 'overlay'); ?>
<?php get_footer(); ?>