<?php get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div class="trailers">
				<h2 class="section-header">Latest Course Review</h2>
				<hr>
				<?php
					$args = array(
						'post_type' => 'course_review',
						'posts_per_page' => 1
					);

					$the_query = new WP_Query($args);
				?>

				

				<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post();
				?>


				<div class="single-post">
					<h1 class="post-tite"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
					<h3>Instructor - <?php the_field('instructor'); ?></h3>
					<div class="featured-image">
						<?php the_post_thumbnail('my-thumbnail'); ?>
					</div>

				</div>
				<?php endwhile; ?>

				<?php endif; ?>
			</div>

			<?php wp_reset_postdata(); ?>
			
			<div class="programmer">
				<h2 class="section-header">Featured Programmer</h2>
				<hr>
				<?php
					$args = array(
						'post_type' => 'programmer',
						'posts_per_page' => 1
					);

					$the_query = new WP_Query($args);
				?>

				

				<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post();
				?>


				<div class="single-post">
					<h1 class="post-tite"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
					<div class="featured-image">
						<?php the_post_thumbnail('my-thumbnail'); ?>
					</div>
					<h4>Nickname: <?php the_field('nickname'); ?> </h4>
					<h4>Age: <?php the_field('age') ?>years old</h4>
					<h4>Nationality: <?php the_field('nationality'); ?></h4>

				</div>
				<?php endwhile; ?>

				<?php endif; ?>
			</div>

			<?php wp_reset_postdata(); ?>
			
			<div class="posts">
				<h2 class="section-header">From the Blog</h2>
				<hr>
				<?php
					$args = array(
						'post_type' => 'post',
						'posts_per_page' => 2
					);

					$the_query = new WP_Query($args);
				?>

				

				<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post();
				?>


				<div class="single-post col-2-item">
					<h1 class="post-tite"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
					<div class="featured-image">
						<?php the_post_thumbnail('my-thumbnail'); ?>
					</div>
					<?php the_excerpt(); ?>

				</div>
				<?php endwhile; ?>

				<?php endif; ?>
			</div>
		</main><!-- #main -->
	</div><!-- #primary -->
	<div class="sidebar" id="homepage-sidebar">
		<?php dynamic_sidebar('Homepage'); ?>
	</div>

	


<?php
get_footer();
?>