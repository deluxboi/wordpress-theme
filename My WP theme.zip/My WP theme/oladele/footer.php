<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Oladele
 */

?>

		</div><!--.container-->
	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="container">
			<div class="footer-sidebar">
				<?php dynamic_sidebar('footer'); ?>
				
			</div>
			<div class="site-info">
				<a href="<?php echo esc_url( __( 'https://github.com/deluxboi/', 'oladele' ) ); ?>"><?php printf( esc_html__( 'Proudly powered by %s', 'oladele' ), 'Delux' ); ?></a>
				<span class="sep"> | </span>
				<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'oladele' ), 'oladele', '<a href="https://github.com/deluxboi//" rel="designer">Oladele.switch.ng</a>' ); ?>
			</div><!-- .site-info -->
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
