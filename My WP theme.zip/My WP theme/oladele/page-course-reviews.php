<?php
/**
 * Template Name: Course Reviews
 */
?>

<?php get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
		<div class="blog-wrapper col-2-items">
			<?php
				$args = array(
					'post_type' => 'course_review'
				);

				$the_query = new WP_Query($args);
			?>

			

			<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post();
			?>


			<div class="single-post col-2-item">
				<h1 class="post-tite"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<div class="featured-image">
					<?php the_post_thumbnail('my-thumbnail'); ?>
					
				</div>
				<div class="course-meta">
					<h3>Instructor - <?php the_field('instructor'); ?></h3>
					
					<p>Synopsis - <?php the_field('synopsis'); ?></p>
				</div>

			</div>
			<?php endwhile; ?>

			<?php endif; ?>
		</div>
	</main>
</div>
<div class="sidebar" id="Course reviews-sidebar">
	<?php dynamic_sidebar('course-review-sidebar'); ?>
</div>
<?php get_footer() ?>
