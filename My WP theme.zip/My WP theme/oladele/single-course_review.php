<?php
/**
 * The template for displaying all courses-review single posts
 
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php while ( have_posts() ) : the_post(); ?>
		
		<h2><?php the_title(); ?></h2>
		<h4>Instructor Name: <?php the_field('instructor'); ?> </h4>
		<?php 
			$date = get_field('date', false, false);
			$date = new DateTime($date);

		?>
		<h4>Starting Date: <?php echo $date->format('j M Y'); ?> </h4>
		<?php the_post_thumbnail(); ?>
		<h4>Basic Knowledge: <?php the_field('language_needed'); ?></h4>
		<h4>Description: </h4>
		<?php the_content(); ?>
			

		<?php endwhile; // End of the loop.?>

		</main><!-- #main -->
	</div><!-- #primary -->

<div class="sidebar" id="Course reviews-sidebar">
	<?php dynamic_sidebar('course-review-sidebar'); ?>
</div>

<?php
get_footer();
?>