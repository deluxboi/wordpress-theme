<?php
	$args = array(
		'category_name' => 'random'
	);

	$the_query = new WP_Query($args);

	$arg = array(
		'category_name' => 'hot'
	);

	$the_newquery = new WP_Query($arg);
?>
<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

	</head>
	<body>
		<div class="row">
			<div class="col-lg-6">
				<!-- Random Posts Category -->
				<h1 class="text-center cat"><strong>RANDOM POSTS</strong></h1>
				<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post();
				?>


				<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<div class="featured-image">
					<?php the_post_thumbnail('my-thumbnail'); ?>
					<span class="image-overlay"></span>
				</div>
				<br />
				<em>Posted On - <?php echo get_the_date(); ?></em>
				<br />
				<em>Written by - <?php the_author(); ?></em>
				<br /><br />
				<?php the_excerpt(); ?>

				<?php endwhile; ?>
				<?php endif; ?>
			</div>

			<div class="col-lg-6">
				<!-- Hot Posts CAtegory -->
				<h1 class="text-center cat"><strong>HOT POSTS</strong></h1>
				<?php if ($the_newquery->have_posts() ): while ($the_newquery->have_posts() ) :$the_newquery->the_post();
				?>


				<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<div class="featured-image">
					<?php the_post_thumbnail('my-thumbnail'); ?>
					<span class="image-overlay"></span>
				</div>
				<br />
				<em>Posted On - <?php echo get_the_date(); ?></em>
				<br />
				<em>Written by - <?php the_author(); ?></em>
				<br /><br />
				<?php the_excerpt(); ?>

				<?php endwhile; ?>
				<?php endif; ?>
			</div>
		</div>

		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>
