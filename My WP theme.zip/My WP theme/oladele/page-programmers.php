<?php
/**
 * Template Name: Programmers
 */
?>

<?php get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
		<div class="blog-wrapper col-2-items">
			<?php
				$args = array(
					'post_type' => 'programmer'
				);

				$the_query = new WP_Query($args);
			?>

			

			<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post();
			?>


			<div class="content-area col-2-item">
				<h1 class="post-tite"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<div class="featured-image">
					<?php the_post_thumbnail('my-thumbnail'); ?>
					<span class="image-overlay"></span>
				</div>
				<div class="programmer-meta">
					<h3>Age - <?php the_field('age'); ?></h3>
					<h3>Nationality - <?php the_field('nationality'); ?></h3>
					<h3>Specialization - <?php the_field('specialization'); ?></h3>
					<?php the_excerpt(); ?>
				</div>

			</div>
			<?php endwhile; ?>

			<?php endif; ?>
	
		</div>
	</main>
</div>

<div class="sidebar" id="Programmers-sidebar">
	<?php dynamic_sidebar('programmer-sidebar'); ?>
</div>
<?php get_footer() ?>
